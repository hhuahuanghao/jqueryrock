package com.jqgrid;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeServlet
 */
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public EmployeeServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.print("Inside Json Constrution method");
		String employeeDetails = "{\n    \"page\": \"1\",\n    \"total\": 1,\n    \"records\": \"12\",\n    \"rows\": [\n        {\n            \"id\": \"1\",\n            \"cell\": [\n                \"Ramu\",\n                \"22\",\n                \"Single\",\n                \"4000$\",\n                \"2\",\n                \"Sincere Worker\"\n            ]\n        },\n        {\n            \"id\": \"3\",\n            \"cell\": [\n                \"Aparna\",\n                \"23\",\n                \"Married\",\n                \"8000$\",\n                \"3\",\n                \"Full time worker\"\n            ]\n        },\n        {\n            \"id\": \"2\",\n            \"cell\": [\n                \"Mathu\",\n                \"34\",\n                \"Married\",\n                \"2000$\",\n                \"4\",\n                \"Part time worker\"\n            ]\n        },\n        {\n            \"id\": \"4\",\n            \"cell\": [\n                \"Kevin\",\n                \"28\",\n                \"Single\",\n                \"8000$\",\n                \"6\",\n                \"Mobile Developer\"\n            ]\n        },\n        {\n            \"id\": \"6\",\n            \"cell\": [\n                \"Peter\",\n                \"34\",\n                \"Single\",\n                \"3400$\",\n                \"1\",\n                \"New Employee\"\n            ]\n        },\n        {\n            \"id\": \"5\",\n            \"cell\": [\n                \"Nambivel\",\n                \"28\",\n                \"Married\",\n                \"2000$\",\n                \"3\",\n                \"Web application developer\"\n            ]\n        },\n        {\n            \"id\": \"7\",\n            \"cell\": [\n                \"Murugan\",\n                \"32\",\n                \"Married\",\n                \"12000$\",\n                \"12\",\n                \"Senior Developer\"\n            ]\n        },\n        {\n            \"id\": \"11\",\n            \"cell\": [\n                \"Vetha\",\n                \"22\",\n                \"Single\",\n                \"6000$\",\n                \"12\",\n                \"Architect\"\n            ]\n        },\n        {\n            \"id\": \"9\",\n            \"cell\": [\n                \"Uma\",\n                \"19\",\n                \"Married\",\n                \"3000$\",\n                \"4\",\n                \"Front End Developer\"\n            ]\n        },\n        {\n            \"id\": \"10\",\n            \"cell\": [\n                \"Kirthika\",\n                \"18\",\n                \"Single\",\n                \"1000$\",\n                \"0\",\n                \"New Joinee\"\n            ]\n        },\n        {\n            \"id\": \"9\",\n            \"cell\": [\n                \"Amarendra\",\n                \"29\",\n                \"Married\",\n                \"2000$\",\n                \"4\",\n                \"Java developer\"\n            ]\n        },\n        {\n            \"id\": \"8\",\n            \"cell\": [\n                \"Idursh\",\n                \"25\",\n                \"Single\",\n                \"2000$\",\n                \"9\",\n                \"Senior Java developer\"\n            ]\n        }\n    ]\n}";
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.print(employeeDetails);
		out.flush();
	}

}
